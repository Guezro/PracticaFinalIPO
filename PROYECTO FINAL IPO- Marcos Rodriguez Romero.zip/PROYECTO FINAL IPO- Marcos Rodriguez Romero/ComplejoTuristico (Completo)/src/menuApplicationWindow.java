import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Panel;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.ScrollPane;
import javax.swing.AbstractAction;
import javax.swing.Action;

public class menuApplicationWindow {
	private JFrame frame;
	private JPanel panel;
	private JButton editorRutaBtn;
	private final Action rutaAction = new editorRutaAction();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menuApplicationWindow window = new menuApplicationWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public JFrame getFrame(){
		return this.frame;
	}
	
	public JPanel getPanel() {
		return this.panel;
	}

	/**
	 * Create the application.
	 */
	public menuApplicationWindow(){
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(Color.WHITE);
		frame.setSize( 1024, 600);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		frame.getContentPane().add(panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] {500, 500};
		gbl_panel.rowHeights = new int[] {550};
		gbl_panel.columnWeights = new double[]{0.0, 1.0};
		gbl_panel.rowWeights = new double[]{1.0};
		panel.setLayout(gbl_panel);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(menuApplicationWindow.class.getResource("/images/menuleft.png")));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		panel.add(lblNewLabel, gbc_lblNewLabel);
		
		Panel panel_1 = new Panel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.gridx = 1;
		gbc_panel_1.gridy = 0;
		panel.add(panel_1, gbc_panel_1);
		panel_1.setLayout(new GridLayout(0, 1, 0, 10));
		
		JLabel lblNewLabel_1 = new JLabel("Menu - Gestion del camping");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Gesti\u00F3n de reservas y estancias");
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Gesti\u00F3n de guias y monitores");
		panel_1.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Gesti\u00F3n de actividades");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel_1.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Gesti\u00F3n de rutas senderistas gratuitas");
		panel_1.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Gesti\u00F3n de Alojamientos");
		panel_1.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Cambiar Idioma");
		panel_1.add(btnNewButton_5);
		
		editorRutaBtn = new JButton("Editor de ruta");
		editorRutaBtn.setAction(rutaAction);
		panel_1.add(editorRutaBtn);

	}

	private class editorRutaAction extends AbstractAction {
		/**
		 * 
		 */
		private static final long serialVersionUID = 2256650402633024764L;
		public editorRutaAction() {
			putValue(NAME, "Editor de Ruta");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			dibujarRutaWindow windowDibujar = new dibujarRutaWindow();
			frame.getContentPane().removeAll();
			//frame.add(windowDibujar.getPanel());
			//windowDibujar.setFrame(frame);
			frame.setContentPane(windowDibujar.getPanel());
			frame.getContentPane().revalidate();
			frame.getContentPane().repaint();
		}
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}
}
