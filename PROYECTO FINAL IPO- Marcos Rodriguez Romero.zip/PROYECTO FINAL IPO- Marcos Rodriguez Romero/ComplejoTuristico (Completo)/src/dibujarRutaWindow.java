import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JTextField;
import java.awt.FlowLayout;
import java.awt.Panel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.Point;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;


public class dibujarRutaWindow {

	private JFrame frame;
	private JPanel panel;
	private JPanel draft;
	private ArrayList<Point> points = new ArrayList<>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					dibujarRutaWindow window = new dibujarRutaWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public JFrame getFrame() {
		return frame;
	}

	/**
	 * Create the application.
	 */
	public dibujarRutaWindow() {
		initialize();		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(Color.WHITE);
		frame.setSize( 1024, 600);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));
		
        panel = new JPanel();
        panel.setBorder(new EmptyBorder(5, 5, 5, 5));
        panel.setLayout(new BorderLayout(0, 0));
        frame.setContentPane(panel);

        draft = new Draft();
        draft.addMouseMotionListener(new MouseMotionAdapter() {

            @Override
            public void mouseDragged(MouseEvent e) {
                frame.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
            	
                points.add(e.getPoint());
                draft.repaint();
            }

        });
        draft.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                points.add(e.getPoint());
                points.add(new Point(-1, -1));
                frame.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
            }
        });
        panel.add(draft, BorderLayout.CENTER);
        draft.setLayout(null);
	}
	
	public class Draft extends JPanel {

        /**
         * 
         */
        private static final long serialVersionUID = 4886600019364448097L;

        public Draft() {
    		
        }
        
        private BufferedImage loadImage(){
            URL imagePath = mainWindow.class.getResource("/images/rutadecares.png");
            BufferedImage result = null;
            try {
                result = ImageIO.read(imagePath);
            } catch (IOException e) {
                System.err.println("Errore, immagine non trovata");
            }
            return result;
        }

        @Override
        protected void paintComponent(Graphics g) {
            // TODO Auto-generated method stub
            super.paintComponent(g);
            Dimension size = getSize();
            BufferedImage bi = loadImage();
            g.drawImage(bi,0,0,size.width,size.height,0,0,bi.getWidth(),bi.getHeight(),null);
            int i = 0;
            while (i < points.size() - 1) {
                Point currentPoint = points.get(i);
                Point nextPoint = points.get(i + 1);

                if (nextPoint.x != -1 && nextPoint.y != -1) {
                    Graphics2D g1 = (Graphics2D) g;
                    RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
                    g1.setRenderingHints(rh);
                    g1.drawLine(currentPoint.x, currentPoint.y, nextPoint.x, nextPoint.y);
                    i++;

                } else {
                    i += 2;
                }
            }
        }
    }

	public JPanel getPanel() {
		return this.panel;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	
}
