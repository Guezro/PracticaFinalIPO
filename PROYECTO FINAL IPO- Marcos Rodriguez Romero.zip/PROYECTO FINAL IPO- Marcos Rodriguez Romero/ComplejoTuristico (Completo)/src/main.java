import javax.swing.JFrame;

import conexion.Conexion;

public class main {
	public static JFrame mainJFrame;

	public static void main(String[] args) {
		main m = new main();
		
	}
	
	public main() {
		mainWindow main = new mainWindow();
		mainJFrame = main.getFrame();
		mainJFrame.setVisible(true);
	}

}
