package formularios;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

public class empleadoForm extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField nombreTextField;
	private JTextField telefonoTextField;
	private JTextField emailTextField;
	private JTextField idiomasTextField;
	private JTextField formacionTextField;
	private JTextField restriccionesHorarioTextField;
	private JComboBox tipoEmpleadoComboBox;
	private JButton avatarSeleccionarButton;
	private JButton enviarButton;
	
	/**
	 * Create the panel.
	 */
	public empleadoForm() {
		this.setSize( 1024, 600);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Formulario de empleados",SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 18));
		lblNewLabel.setBounds(450, 11, 182, 62);
		add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Imagen");
		lblNewLabel_2.setIcon(new ImageIcon(reservaForm.class.getResource("/images/loginleft.png")));
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setBounds(0, 0, 382, 600);
		add(lblNewLabel_2);
		
		tipoEmpleadoComboBox = new JComboBox();
		tipoEmpleadoComboBox.setBounds(450, 103, 195, 22);
		add(tipoEmpleadoComboBox);
		
		JLabel tipoEmpleadoLabel = new JLabel("Tipo de empleado");
		tipoEmpleadoLabel.setBounds(450, 77, 195, 28);
		add(tipoEmpleadoLabel);
		
		JLabel nombreLabel = new JLabel("Nombre");
		nombreLabel.setBounds(450, 136, 195, 28);
		add(nombreLabel);
		
		nombreTextField = new JTextField();
		nombreTextField.setColumns(10);
		nombreTextField.setBounds(450, 164, 195, 20);
		add(nombreTextField);
		
		JLabel telefonoLabel = new JLabel("Telefono");
		telefonoLabel.setBounds(450, 195, 195, 28);
		add(telefonoLabel);
		
		telefonoTextField = new JTextField();
		telefonoTextField.setColumns(10);
		telefonoTextField.setBounds(450, 223, 195, 20);
		add(telefonoTextField);
		
		JLabel emailLabel = new JLabel("Email");
		emailLabel.setBounds(450, 254, 195, 28);
		add(emailLabel);
		
		emailTextField = new JTextField();
		emailTextField.setColumns(10);
		emailTextField.setBounds(450, 282, 195, 20);
		add(emailTextField);
		
		JLabel idiomasLabel = new JLabel("Idiomas");
		idiomasLabel.setBounds(450, 313, 195, 28);
		add(idiomasLabel);
		
		idiomasTextField = new JTextField();
		idiomasTextField.setColumns(10);
		idiomasTextField.setBounds(450, 341, 195, 20);
		add(idiomasTextField);
		
		JLabel formacionLabel = new JLabel("Formacion");
		formacionLabel.setBounds(450, 372, 195, 28);
		add(formacionLabel);
		
		formacionTextField = new JTextField();
		formacionTextField.setColumns(10);
		formacionTextField.setBounds(450, 400, 195, 20);
		add(formacionTextField);
		
		restriccionesHorarioTextField = new JTextField();
		restriccionesHorarioTextField.setColumns(10);
		restriccionesHorarioTextField.setBounds(655, 105, 195, 20);
		add(restriccionesHorarioTextField);
		
		JLabel restriccionesLabel = new JLabel("Restricciones de horario");
		restriccionesLabel.setBounds(655, 77, 195, 28);
		add(restriccionesLabel);
		
		JLabel avaterLabel = new JLabel("Avatar");
		avaterLabel.setBounds(655, 136, 195, 28);
		add(avaterLabel);
		
		avatarSeleccionarButton = new JButton("Seleccionar");
		avatarSeleccionarButton.setBounds(655, 163, 89, 23);
		add(avatarSeleccionarButton);
		
		JLabel avatarFotoLabel = new JLabel("Foto");
		avatarFotoLabel.setBounds(655, 187, 195, 210);
		add(avatarFotoLabel);
		
		enviarButton = new JButton("Enviar");
		enviarButton.setBounds(450, 539, 103, 36);
		add(enviarButton);
	}
}
