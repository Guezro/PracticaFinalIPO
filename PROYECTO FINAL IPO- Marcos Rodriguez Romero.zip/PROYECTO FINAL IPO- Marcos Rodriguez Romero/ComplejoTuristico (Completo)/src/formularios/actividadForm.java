package formularios;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JTextArea;

public class actividadForm extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JButton enviarButton;
	private JLabel lblTipoDeEmpleado;
	private JComboBox empleadoComboBox;
	private JLabel horarioLabel;
	private JTextField horarioTextField;
	private JLabel cupoMinimoLabel;
	private JTextField cupoMinimoTextField;
	private JLabel cupoMaximoLabel;
	private JTextField cupoMaximoTextField;
	private JTextArea caracteristicasDestinatariosTextArea;
	private JTextField precioHoraMesTextField;
	private JTextField precioTextField;
	private JTextField areaTextField;
	private JLabel caracteristicasDestinatariosLabel;
	private JLabel precioHoraMesLabel;
	private JLabel precioLabel;
	private JLabel areaLabel;
	private JLabel descripcionLabel;
	private JTextArea descripcionTextArea;
	private JLabel materialesLabel;
	private JTextArea materialesTextArea;

	/**
	 * Create the panel.
	 */
	public actividadForm() {
		this.setSize( 1024, 600);
		setLayout(null);
		
		lblNewLabel = new JLabel("Formulario de actividad",SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 18));
		lblNewLabel.setBounds(450, 11, 182, 62);
		add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("Imagen");
		lblNewLabel_2.setIcon(new ImageIcon(reservaForm.class.getResource("/images/loginleft.png")));
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setBounds(0, 0, 382, 600);
		add(lblNewLabel_2);
		
		enviarButton = new JButton("Enviar");
		enviarButton.setBounds(450, 539, 103, 36);
		add(enviarButton);
		
		lblTipoDeEmpleado = new JLabel("Empleado");
		lblTipoDeEmpleado.setBounds(450, 72, 195, 28);
		add(lblTipoDeEmpleado);
		
		empleadoComboBox = new JComboBox();
		empleadoComboBox.setBounds(450, 98, 195, 22);
		add(empleadoComboBox);
		
		horarioLabel = new JLabel("Horario");
		horarioLabel.setBounds(450, 131, 195, 28);
		add(horarioLabel);
		
		horarioTextField = new JTextField();
		horarioTextField.setColumns(10);
		horarioTextField.setBounds(450, 159, 195, 20);
		add(horarioTextField);
		
		cupoMinimoLabel = new JLabel("Cupo minimo");
		cupoMinimoLabel.setBounds(450, 190, 195, 28);
		add(cupoMinimoLabel);
		
		cupoMinimoTextField = new JTextField();
		cupoMinimoTextField.setColumns(10);
		cupoMinimoTextField.setBounds(450, 218, 195, 20);
		add(cupoMinimoTextField);
		
		cupoMaximoLabel = new JLabel("Cupo maximo");
		cupoMaximoLabel.setBounds(450, 249, 195, 28);
		add(cupoMaximoLabel);
		
		cupoMaximoTextField = new JTextField();
		cupoMaximoTextField.setColumns(10);
		cupoMaximoTextField.setBounds(450, 277, 195, 20);
		add(cupoMaximoTextField);
		
		caracteristicasDestinatariosLabel = new JLabel("Caracteristicas de Destinatarios");
		caracteristicasDestinatariosLabel.setBounds(450, 308, 195, 28);
		add(caracteristicasDestinatariosLabel);
		
		caracteristicasDestinatariosTextArea = new JTextArea();
		caracteristicasDestinatariosTextArea.setLineWrap(true);
		caracteristicasDestinatariosTextArea.setBounds(450, 333, 195, 103);
		caracteristicasDestinatariosTextArea.setLineWrap(true);
		Border border = BorderFactory.createLineBorder(Color.GRAY);
		caracteristicasDestinatariosTextArea.setBorder(BorderFactory.createCompoundBorder(border,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		add(caracteristicasDestinatariosTextArea);
		
		precioHoraMesLabel = new JLabel("Precio hora/mes");
		precioHoraMesLabel.setBounds(450, 447, 195, 28);
		add(precioHoraMesLabel);
		
		precioHoraMesTextField = new JTextField();
		precioHoraMesTextField.setColumns(10);
		precioHoraMesTextField.setBounds(450, 475, 195, 20);
		add(precioHoraMesTextField);
		
		precioLabel = new JLabel("Precio");
		precioLabel.setBounds(655, 72, 195, 28);
		add(precioLabel);
		
		precioTextField = new JTextField();
		precioTextField.setColumns(10);
		precioTextField.setBounds(655, 100, 195, 20);
		add(precioTextField);
		
		areaLabel = new JLabel("Area");
		areaLabel.setBounds(655, 131, 195, 28);
		add(areaLabel);
		
		areaTextField = new JTextField();
		areaTextField.setColumns(10);
		areaTextField.setBounds(655, 159, 195, 20);
		add(areaTextField);
		
		descripcionLabel = new JLabel("Descripcion");
		descripcionLabel.setBounds(655, 190, 195, 28);
		add(descripcionLabel);
		
		descripcionTextArea = new JTextArea();
		descripcionTextArea.setLineWrap(true);
		descripcionTextArea.setBounds(655, 215, 195, 103);
		descripcionTextArea.setLineWrap(true);
		Border border2 = BorderFactory.createLineBorder(Color.GRAY);
		descripcionTextArea.setBorder(BorderFactory.createCompoundBorder(border2,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		add(descripcionTextArea);
		
		materialesLabel = new JLabel("Materiales");
		materialesLabel.setBounds(655, 329, 195, 28);
		add(materialesLabel);
		
		materialesTextArea = new JTextArea();
		materialesTextArea.setLineWrap(true);
		materialesTextArea.setBounds(655, 354, 195, 103);
		Border border3 = BorderFactory.createLineBorder(Color.GRAY);
		materialesTextArea.setBorder(BorderFactory.createCompoundBorder(border3,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		add(materialesTextArea);
	}
}
