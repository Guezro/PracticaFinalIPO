package formularios;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JList;

public class bungalowForm extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JTextField ubicacionTextField;
	private JTextField capacidadTextField;
	private JTextField precioTextField;
	private JTextField estanciaMinimaextField;
	private JTextField estanciaMaximaTextField;
	private JLabel dimensionesLabel;
	private JTextField altoTextField;
	private JTextField anchoTextField;
	private JLabel altoLabel;
	private JLabel anchoLabel;
	private JLabel ubicacionLabel;
	private JLabel capacidadLabel;
	private JLabel precioLabel;
	private JLabel estanciaMinimaLabel;
	private JLabel estanciaMaximaLabel;
	private JComboBox serviciosComboBox;
	private JLabel serviciosLabel;
	private JLabel solicitudesEspecialesLabel;
	private JTextArea solicitudesEspecialesTextArea;
	private JLabel galeriaFotosLabel;
	private JList galeriaFotosList;
	private JButton enviarButton;
	
	/**
	 * Create the panel.
	 */
	public bungalowForm() {
		this.setSize( 1024, 600);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Formulario de bungalows",SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 18));
		lblNewLabel.setBounds(450, 11, 182, 62);
		add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Imagen");
		lblNewLabel_2.setIcon(new ImageIcon(reservaForm.class.getResource("/images/loginleft.png")));
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setBounds(0, 0, 382, 600);
		add(lblNewLabel_2);
		
		dimensionesLabel = new JLabel("Dimensiones");
		dimensionesLabel.setBounds(450, 133, 195, 28);
		add(dimensionesLabel);
		
		altoTextField = new JTextField();
		altoTextField.setBounds(484, 168, 86, 20);
		add(altoTextField);
		altoTextField.setColumns(10);
		
		anchoTextField = new JTextField();
		anchoTextField.setColumns(10);
		anchoTextField.setBounds(484, 199, 86, 20);
		add(anchoTextField);
		
		altoLabel = new JLabel("Alto");
		altoLabel.setBounds(450, 168, 37, 20);
		add(altoLabel);
		
		anchoLabel = new JLabel("Ancho");
		anchoLabel.setBounds(450, 199, 37, 20);
		add(anchoLabel);
		
		ubicacionLabel = new JLabel("Ubicacion");
		ubicacionLabel.setBounds(450, 74, 195, 28);
		add(ubicacionLabel);
		
		ubicacionTextField = new JTextField();
		ubicacionTextField.setBounds(450, 102, 195, 20);
		add(ubicacionTextField);
		ubicacionTextField.setColumns(10);
		
		capacidadLabel = new JLabel("Capacidad");
		capacidadLabel.setBounds(450, 230, 195, 28);
		add(capacidadLabel);
		
		capacidadTextField = new JTextField();
		capacidadTextField.setColumns(10);
		capacidadTextField.setBounds(450, 257, 195, 20);
		add(capacidadTextField);
		
		precioLabel = new JLabel("Precio");
		precioLabel.setBounds(450, 288, 195, 28);
		add(precioLabel);
		
		precioTextField = new JTextField();
		precioTextField.setColumns(10);
		precioTextField.setBounds(450, 316, 195, 20);
		add(precioTextField);
		
		estanciaMinimaLabel = new JLabel("Escancia minima (d\u00EDas)");
		estanciaMinimaLabel.setBounds(450, 347, 195, 28);
		add(estanciaMinimaLabel);
		
		estanciaMinimaextField = new JTextField();
		estanciaMinimaextField.setColumns(10);
		estanciaMinimaextField.setBounds(450, 375, 195, 20);
		add(estanciaMinimaextField);
		
		estanciaMaximaLabel = new JLabel("Estancia maxima (d\u00EDas)");
		estanciaMaximaLabel.setBounds(450, 406, 195, 28);
		add(estanciaMaximaLabel);
		
		estanciaMaximaTextField = new JTextField();
		estanciaMaximaTextField.setColumns(10);
		estanciaMaximaTextField.setBounds(450, 434, 195, 20);
		add(estanciaMaximaTextField);
		
		serviciosComboBox = new JComboBox();
		serviciosComboBox.setBounds(450, 491, 195, 22);
		add(serviciosComboBox);
		
		serviciosLabel = new JLabel("Servicios");
		serviciosLabel.setBounds(450, 465, 195, 28);
		add(serviciosLabel);
		
		solicitudesEspecialesLabel = new JLabel("Solicitudes especiales");
		solicitudesEspecialesLabel.setBounds(655, 74, 308, 28);
		add(solicitudesEspecialesLabel);
		
		solicitudesEspecialesTextArea = new JTextArea();
		solicitudesEspecialesTextArea.setLineWrap(true);
		solicitudesEspecialesTextArea.setBounds(655, 102, 308, 81);
		solicitudesEspecialesTextArea.setLineWrap(true);
		Border border = BorderFactory.createLineBorder(Color.GRAY);
	    solicitudesEspecialesTextArea.setBorder(BorderFactory.createCompoundBorder(border,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		add(solicitudesEspecialesTextArea);
		
		galeriaFotosLabel = new JLabel("Galeria de fotos");
		galeriaFotosLabel.setBounds(655, 199, 195, 28);
		add(galeriaFotosLabel);
		
		Object fotos[]= { "Monday","Tuesday","Wednesday",
                "Thursday","Friday","Saturday"};
		galeriaFotosList = new JList(fotos);
		galeriaFotosList.setBounds(655, 230, 308, 165);
		add(galeriaFotosList);
		
		enviarButton = new JButton("Enviar");
		enviarButton.setBounds(450, 539, 103, 36);
		add(enviarButton);
	}
}
