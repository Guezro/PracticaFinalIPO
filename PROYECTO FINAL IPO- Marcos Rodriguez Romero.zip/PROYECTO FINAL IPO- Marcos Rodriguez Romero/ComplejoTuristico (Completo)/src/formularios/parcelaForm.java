package formularios;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;

public class parcelaForm extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textField;
	private JTextField altoTextField;
	private JTextField anchoTextField;
	private JTextField ubicacionTextField;
	private JComboBox tipoParcelaComboBox;
	private JComboBox serviciosComboBox;
	private JButton enviarButton;

	/**
	 * Create the panel.
	 */
	public parcelaForm() {
		this.setSize( 1024, 600);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Formulario de parcelas",SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 18));
		lblNewLabel.setBounds(450, 11, 172, 62);
		add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Imagen");
		lblNewLabel_2.setIcon(new ImageIcon(reservaForm.class.getResource("/images/loginleft.png")));
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setBounds(0, 0, 382, 600);
		add(lblNewLabel_2);
		
		JLabel tipoParcelaLabel = new JLabel("Tipo de Parcela");
		tipoParcelaLabel.setBounds(450, 72, 195, 28);
		add(tipoParcelaLabel);
		
		tipoParcelaComboBox = new JComboBox();
		tipoParcelaComboBox.setBounds(450, 100, 382, 22);
		add(tipoParcelaComboBox);
		
		JLabel dimensionesLabel = new JLabel("Dimensiones");
		dimensionesLabel.setBounds(450, 133, 195, 28);
		add(dimensionesLabel);
		
		altoTextField = new JTextField();
		altoTextField.setBounds(484, 168, 86, 20);
		add(altoTextField);
		altoTextField.setColumns(10);
		
		anchoTextField = new JTextField();
		anchoTextField.setColumns(10);
		anchoTextField.setBounds(484, 199, 86, 20);
		add(anchoTextField);
		
		JLabel altoLabel = new JLabel("Alto");
		altoLabel.setBounds(450, 168, 37, 20);
		add(altoLabel);
		
		JLabel anchoLabel = new JLabel("Ancho");
		anchoLabel.setBounds(450, 199, 37, 20);
		add(anchoLabel);
		
		JLabel ubicacionLabel = new JLabel("Ubicacion");
		ubicacionLabel.setBounds(450, 230, 195, 28);
		add(ubicacionLabel);
		
		ubicacionTextField = new JTextField();
		ubicacionTextField.setBounds(450, 257, 382, 20);
		add(ubicacionTextField);
		ubicacionTextField.setColumns(10);
		
		JLabel serviciosLabel = new JLabel("Servicios");
		serviciosLabel.setBounds(450, 286, 195, 28);
		add(serviciosLabel);
		
		serviciosComboBox = new JComboBox();
		serviciosComboBox.setBounds(450, 312, 382, 22);
		add(serviciosComboBox);
		
		enviarButton = new JButton("Enviar");
		enviarButton.setBounds(450, 539, 103, 36);
		add(enviarButton);
	}
}
