package formularios;

import java.awt.Color;
import java.awt.Font;

import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextArea;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JMonthChooser;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JDateChooser;
import javax.swing.JList;
import javax.swing.JComboBox;

public class reservaForm extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField telefonoTextField;
	private JTextField emailTextField;
	private JTextField numeroOcupantesTextField;
	private JTextArea solicitudesEspecialesTextArea;
	private JButton enviarButton;
	private JDateChooser fechaEntradaDateChooser;
	private JDateChooser fechaSalidaDateChooser;
	private JComboBox alojamientoComboBox;
	
	/**
	 * Create the panel.
	 */
	public reservaForm() {
		this.setSize( 1024, 600);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Formulario de reservas",SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 18));
		lblNewLabel.setBounds(450, 11, 172, 62);
		add(lblNewLabel);
		
		telefonoTextField = new JTextField();
		telefonoTextField.setBounds(450, 274, 382, 20);
		add(telefonoTextField);
		telefonoTextField.setColumns(10);
		
		emailTextField = new JTextField();
		emailTextField.setBounds(450, 328, 382, 20);
		add(emailTextField);
		emailTextField.setColumns(10);
		
		numeroOcupantesTextField = new JTextField();
		numeroOcupantesTextField.setBounds(450, 388, 382, 20);
		add(numeroOcupantesTextField);
		numeroOcupantesTextField.setColumns(10);
		
		solicitudesEspecialesTextArea = new JTextArea();
		solicitudesEspecialesTextArea.setBounds(450, 447, 382, 81);
		solicitudesEspecialesTextArea.setLineWrap(true);
		Border border = BorderFactory.createLineBorder(Color.GRAY);
	    solicitudesEspecialesTextArea.setBorder(BorderFactory.createCompoundBorder(border,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		add(solicitudesEspecialesTextArea);
		
		JLabel fechaEntradaLabel = new JLabel("Fecha de entrada");
		fechaEntradaLabel.setBounds(450, 133, 195, 28);
		add(fechaEntradaLabel);
		
		JLabel fechaSalidaLabel = new JLabel("Fecha de salida");
		fechaSalidaLabel.setBounds(450, 187, 195, 28);
		add(fechaSalidaLabel);
		
		JLabel telefonoLabel = new JLabel("Telefono");
		telefonoLabel.setBounds(450, 246, 195, 28);
		add(telefonoLabel);
		
		JLabel emailLabel = new JLabel("Email");
		emailLabel.setBounds(450, 299, 195, 28);
		add(emailLabel);
		
		JLabel numeroOcupantesLabel = new JLabel("Numero de ocupantes");
		numeroOcupantesLabel.setBounds(450, 359, 195, 28);
		add(numeroOcupantesLabel);
		
		JLabel solicitudesEspecialesLabel = new JLabel("Solicitudes especiales");
		solicitudesEspecialesLabel.setBounds(450, 419, 195, 28);
		add(solicitudesEspecialesLabel);
		
		enviarButton = new JButton("Enviar");
		enviarButton.setBounds(450, 539, 103, 36);
		add(enviarButton);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(reservaForm.class.getResource("/images/loginleft.png")));
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setBounds(0, 0, 382, 600);
		add(lblNewLabel_2);
		
		JLabel label = DefaultComponentFactory.getInstance().createTitle("New JGoodies title");
		label.setBounds(0, 168, 88, 14);
		add(label);
		
		fechaEntradaDateChooser = new JDateChooser();
		fechaEntradaDateChooser.setBounds(450, 162, 384, 20);
		fechaEntradaDateChooser.setDateFormatString("d/MM/YYY");
		add(fechaEntradaDateChooser);
		
		fechaSalidaDateChooser = new JDateChooser();
		fechaSalidaDateChooser.setBounds(450, 215, 384, 20);
		fechaSalidaDateChooser.setDateFormatString("d/MM/YYY");
		add(fechaSalidaDateChooser);
		
		String country[]={"Parcela","Bungalow"};
		alojamientoComboBox = new JComboBox(country);
		alojamientoComboBox.setBounds(450, 100, 382, 22);
		add(alojamientoComboBox);
		
		JLabel alojamientoLabel = new JLabel("Alojamiento");
		alojamientoLabel.setBounds(450, 72, 195, 28);
		add(alojamientoLabel);
	}
}
