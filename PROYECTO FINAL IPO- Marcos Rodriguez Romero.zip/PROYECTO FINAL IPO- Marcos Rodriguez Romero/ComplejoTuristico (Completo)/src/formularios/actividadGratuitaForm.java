package formularios;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

public class actividadGratuitaForm extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JButton enviarButton;
	private JTextField horarioTextField;
	private JTextField cupoMinimoTextField;
	private JTextField cupoMaximoTextField;
	private JTextField precioHoraMesTextField;
	private JTextField precioTextField;
	private JTextField areaTextField;
	private JTextField puntoEncuentroTextField;
	private JTextField dificultadTextField;
	private JLabel empleadoLabel;
	private JComboBox empleadoComboBox;
	private JLabel horarioLabel;
	private JLabel cupoMinimoLabel;
	private JLabel cupoMaximoLabel;
	private JLabel caracteristicasDestinatariosLabel;
	private JTextArea caracteristicasDestinatariosTextArea;
	private JLabel precioHoraMesLabel;
	private JLabel precioLabel;
	private JLabel areaLabel;
	private JLabel descripcionLabel;
	private JTextArea descripcionTextArea;
	private JLabel materialesLabel;
	private JTextArea materialesTextArea;
	private JLabel puntoEncuentroLabel;
	private JLabel dificultadLabel;
	
	/**
	 * Create the panel.
	 */
	public actividadGratuitaForm() {
		this.setSize( 1024, 600);
		setLayout(null);
		
		lblNewLabel = new JLabel("Formulario de actividad",SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 18));
		lblNewLabel.setBounds(450, 11, 182, 62);
		add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("Imagen");
		lblNewLabel_2.setIcon(new ImageIcon(reservaForm.class.getResource("/images/loginleft.png")));
		lblNewLabel_2.setBackground(Color.BLACK);
		lblNewLabel_2.setBounds(0, 0, 382, 600);
		add(lblNewLabel_2);
		
		enviarButton = new JButton("Enviar");
		enviarButton.setBounds(450, 539, 103, 36);
		add(enviarButton);
		
		empleadoLabel = new JLabel("Empleado");
		empleadoLabel.setBounds(450, 72, 195, 28);
		add(empleadoLabel);
		
		empleadoComboBox = new JComboBox();
		empleadoComboBox.setBounds(450, 98, 195, 22);
		add(empleadoComboBox);
		
		horarioLabel = new JLabel("Horario");
		horarioLabel.setBounds(450, 131, 195, 28);
		add(horarioLabel);
		
		horarioTextField = new JTextField();
		horarioTextField.setColumns(10);
		horarioTextField.setBounds(450, 159, 195, 20);
		add(horarioTextField);
		
		cupoMinimoLabel = new JLabel("Cupo minimo");
		cupoMinimoLabel.setBounds(450, 190, 195, 28);
		add(cupoMinimoLabel);
		
		cupoMinimoTextField = new JTextField();
		cupoMinimoTextField.setColumns(10);
		cupoMinimoTextField.setBounds(450, 218, 195, 20);
		add(cupoMinimoTextField);
		
		cupoMaximoLabel = new JLabel("Cupo maximo");
		cupoMaximoLabel.setBounds(450, 249, 195, 28);
		add(cupoMaximoLabel);
		
		cupoMaximoTextField = new JTextField();
		cupoMaximoTextField.setColumns(10);
		cupoMaximoTextField.setBounds(450, 277, 195, 20);
		add(cupoMaximoTextField);
		
		caracteristicasDestinatariosLabel = new JLabel("Caracteristicas de Destinatarios");
		caracteristicasDestinatariosLabel.setBounds(450, 308, 195, 28);
		add(caracteristicasDestinatariosLabel);
		
		caracteristicasDestinatariosTextArea = new JTextArea();
		caracteristicasDestinatariosTextArea.setLineWrap(true);
		caracteristicasDestinatariosTextArea.setBounds(450, 333, 195, 103);
		caracteristicasDestinatariosTextArea.setLineWrap(true);
		Border border = BorderFactory.createLineBorder(Color.GRAY);
	    caracteristicasDestinatariosTextArea.setBorder(BorderFactory.createCompoundBorder(border,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		add(caracteristicasDestinatariosTextArea);
		
		precioHoraMesTextField = new JTextField();
		precioHoraMesTextField.setColumns(10);
		precioHoraMesTextField.setBounds(450, 475, 195, 20);
		add(precioHoraMesTextField);
		
		precioHoraMesLabel = new JLabel("Precio hora/mes");
		precioHoraMesLabel.setBounds(450, 447, 195, 28);
		add(precioHoraMesLabel);
		
		precioTextField = new JTextField();
		precioTextField.setColumns(10);
		precioTextField.setBounds(655, 100, 195, 20);
		add(precioTextField);
		
		precioLabel = new JLabel("Precio");
		precioLabel.setBounds(655, 72, 195, 28);
		add(precioLabel);
		
		areaTextField = new JTextField();
		areaTextField.setColumns(10);
		areaTextField.setBounds(655, 159, 195, 20);
		add(areaTextField);
		
		areaLabel = new JLabel("Area");
		areaLabel.setBounds(655, 131, 195, 28);
		add(areaLabel);
		
		descripcionLabel = new JLabel("Descripcion");
		descripcionLabel.setBounds(655, 190, 195, 28);
		add(descripcionLabel);
		
		descripcionTextArea = new JTextArea();
		descripcionTextArea.setLineWrap(true);
		descripcionTextArea.setBounds(655, 215, 195, 83);
		descripcionTextArea.setLineWrap(true);
		Border border2 = BorderFactory.createLineBorder(Color.GRAY);
	    descripcionTextArea.setBorder(BorderFactory.createCompoundBorder(border2,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		add(descripcionTextArea);
		
		materialesLabel = new JLabel("Materiales");
		materialesLabel.setBounds(655, 308, 195, 28);
		add(materialesLabel);
		
		materialesTextArea = new JTextArea();
		materialesTextArea.setLineWrap(true);
		materialesTextArea.setBounds(655, 333, 195, 83);
		Border border3 = BorderFactory.createLineBorder(Color.GRAY);
	    materialesTextArea.setBorder(BorderFactory.createCompoundBorder(border3,
	            BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		add(materialesTextArea);
		
		puntoEncuentroTextField = new JTextField();
		puntoEncuentroTextField.setColumns(10);
		puntoEncuentroTextField.setBounds(655, 451, 195, 20);
		add(puntoEncuentroTextField);
		
		puntoEncuentroLabel = new JLabel("Punto de encuentro");
		puntoEncuentroLabel.setBounds(655, 427, 195, 28);
		add(puntoEncuentroLabel);
		
		dificultadTextField = new JTextField();
		dificultadTextField.setColumns(10);
		dificultadTextField.setBounds(655, 503, 195, 20);
		add(dificultadTextField);
		
		dificultadLabel = new JLabel("Dificultad");
		dificultadLabel.setBounds(655, 475, 195, 28);
		add(dificultadLabel);
	}
}
