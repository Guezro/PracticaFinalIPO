package complementos;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

public class JTableButtonModel extends AbstractTableModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Object[][] rows = {
            { "Kundan Kumar Jha", "4031", new JButton("bonti") },
            { "Anand Jha", "6014", new JButton("boton") }
        };
	String[] columns = { "Name", "Roll Number", "Department" };
	
	
	public Object[][] getRows() {
		return rows;
	}
	public void setRows(Object[][] rows) {
		this.rows = rows;
	}
	public String[] getColumns() {
		return columns;
	}
	public void setColumns(String[] columns) {
		this.columns = columns;
	}
	public String getColumnName(int column) {
	      return columns[column];
	   }
	   public int getRowCount() {
	      return rows.length;
	   }
	   public int getColumnCount() {
	      return columns.length;
	   }
	   public Object getValueAt(int row, int column) {
	      return rows[row][column];
	   }
	   public boolean isCellEditable(int row, int column) {
	      return false;
	   }
	   public Class getColumnClass(int column) {
	      return getValueAt(0, column).getClass();
	   }
}
