package Interfaces;

import modelo.Temporada;

public interface Temporadas {
	default Temporada[] getTemporadas() {
		Temporada[] temporadas = {new Temporada("baja", "04/01", "06/22"), new Temporada("media", "06/23", "08/01"), new Temporada("alta", "08/02", "03/31")};
		return temporadas;
	}
}
