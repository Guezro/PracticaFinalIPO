package repositorio;
import java.sql.*;
import conexion.Conexion;
import modelo.Usuario;

public class usuarioRepository {
	Connection conn = null;
	Statement stmt = null;
	public usuarioRepository() {
		super();
	
	}
	
	public Usuario loginUsuario(String username, String clave) {
		Conexion con = new Conexion();
		Usuario usuario = null;
		try {
			conn = con.getCon();
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( "SELECT * FROM USUARIO WHERE USERNAME = '"+username+"' AND CLAVE = '"+clave+"';" );
		      
		      while ( rs.next() ) {
	    	     usuario = new Usuario(rs.getString("USERNAME"),rs.getString("USERNAME"),rs.getString("EMAIL"),"");
		      }
		      rs.close();
		      stmt.close();
		      conn.close();
		      return usuario;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
