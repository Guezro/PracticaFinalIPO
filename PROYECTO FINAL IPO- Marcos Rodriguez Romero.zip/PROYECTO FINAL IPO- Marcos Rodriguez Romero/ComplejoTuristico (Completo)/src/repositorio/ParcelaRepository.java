package repositorio;
import java.sql.*;
import java.util.ArrayList;

import conexion.Conexion;
import modelo.Parcela;

public class ParcelaRepository {
	ArrayList<Parcela> parcelas = null;
	Connection conn = null;
	Statement stmt = null;
	public ParcelaRepository() {
		super();
		parcelas = new ArrayList<Parcela>();
	}
	
	public ArrayList<Parcela> fetchParcelas() {
		Conexion con = new Conexion();
		try {
			conn = con.getCon();
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( "SELECT * FROM PARCELA;" );
		      
		      while ( rs.next() ) {
	    	     Parcela parcela = new Parcela(	rs.getString("DISPONIBLE"), 
	    	    		 						rs.getInt("PARCELAID"),
	    	    		 						rs.getDouble("TAMANO_X"), 
	    	    		 						rs.getDouble("TAMANO_Y"), 
	    	    		 						rs.getString("UBICACION"), 
	    	    		 						rs.getString("SERVICIOS").split(","));
		         parcelas.add(parcela);
		      }
		      rs.close();
		      stmt.close();
		      conn.close();
		      return parcelas;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
