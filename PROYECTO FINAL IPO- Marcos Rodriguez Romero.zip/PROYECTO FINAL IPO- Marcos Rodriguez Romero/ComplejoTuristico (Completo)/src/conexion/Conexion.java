package conexion;

import java.sql.*;

public class Conexion {
	Connection con = null;
	Statement stmt = null;

	public Conexion() {
		super();
		try {
			Class.forName("org.sqlite.JDBC");
			con = DriverManager.getConnection("jdbc:sqlite:complejoturistico.db");
			con.setAutoCommit(false);
		} catch (Exception e) {
			System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		}
		System.out.println("Base de datos conectada");
	}
	
	public void llenarDatos() {
		try {
			stmt = con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}

	public Statement getStmt() {
		return stmt;
	}

	public void setStmt(Statement stmt) {
		this.stmt = stmt;
	}

	public boolean CrearBD() {
		try {
			stmt = con.createStatement();
			String sql = "CREATE TABLE USUARIO " +
                    "(ID 			INT PRIMARY KEY     NOT NULL," +
                    " USERNAME      CHAR(50)    		NOT NULL, " + 
                    " EMAIL         CHAR(200)     		NOT NULL, " + 
                    " ADDRESS       TEXT, " +
                    " CLAVE			CHAR(200),"+
                    " AVATAR_URL	TEXT,"+
                    " ULTIMO_ACCESO	CHAR(50));"; 
			 stmt.executeUpdate(sql);
			 sql = "CREATE TABLE PARCELA("
			 		+ "ID			INT PRIMARY KEY		NOT NULL,"
			 		+ "PARCELAID	INT					NOT NULL,"
			 		+ "TAMANO_X		REAL				NOT NULL,"
			 		+ "TAMANO_Y		REAL				NOT NULL,"
			 		+ "UBICACION	TEXT						,"
			 		+ "DISPONIBLE	TEXT				NOT NULL,"
			 		+ "SERVICIOS	TEXT"
			 		+ ");";
			 stmt.executeUpdate(sql);
			 sql = "CREATE TABLE BUNGALOW("
			 		+ "ID			INT PRIMARY KEY		NOT NULL,"
			 		+ "TAMANO_X		REAL				NOT NULL,"
			 		+ "TAMANO_Y		REAL				NOT NULL,"
			 		+ "UBICACION	TEXT						,"
			 		+ "CAPACIDAD	INT					NOT NULL,"
			 		+ "PRECIO		REAL						,"
			 		+ "DISPONIBLE	TEXT				NOT NULL,"
			 		+ "ESTANCIA_MIN	INT					NOT NULL,"
			 		+ "ESTANCIA_MAX	INT					NOT NULL,"
			 		+ "SERVICIOS	TEXT						,"
			 		+ "DESCRIPCION	TEXT						,"
			 		+ "GALERIA		TEXT"
			 		+ ");";
			 stmt.executeUpdate(sql);
			 sql = "CREATE TABLE RESERVA("
			 		+ "ID				INT PRIMARY KEY		NOT NULL,"
			 		+ "FECHA_ENTRADA	CHAR(50)			NOT NULL,"
			 		+ "FECHA_SALIDA		CHAR(50)			NOT NULL,"
			 		+ "REALIZADO_POR	INT					NOT NULL,"
			 		+ "TELEFONO			TEXT						,"
			 		+ "EMAIL			TEXT						,"
			 		+ "OCUPANTES		INT					NOT NULL,"
			 		+ "SOLICITUDES		TEXT"
			 		+ ");";
			 stmt.executeUpdate(sql);
			 sql = "CREATE TABLE EMPLEADO("
			 		+ "ID				INT PRIMARY KEY		NOT NULL,"
			 		+ "NOMBRES			TEXT				NOT NULL,"
			 		+ "TELEFONO			TEXT						,"
			 		+ "EMAIL			TEXT						,"
			 		+ "IDIOMAS			TEXT						,"
			 		+ "FORMACION		TEXT						,"
			 		+ "AVATAR			TEXT						,"
			 		+ "ULTIMO_ACCESO	CHAR(50)					,"
			 		+ "TIPO				TEXT"
			 		+ ");";
			 stmt.executeUpdate(sql);
			 sql = "CREATE TABLE ACTIVIDAD("
			 		+ "ID				INT PRIMARY KEY		NOT NULL,"
			 		+ "MONITORES		TEXT				NOT NULL,"
			 		+ "HORARIO			TEXT				NOT NULL,"
			 		+ "CUPO_MINIMO		INT					NOT NULL,"
			 		+ "CUPO_MAXIMO		INT					NOT NULL,"
			 		+ "CARACTERISTICAS	TEXT				NOT NULL,"
			 		+ "PRECIO_HM		INT					NOT NULL,"
			 		+ "PRECIO			REAL				NOT NULL,"
			 		+ "AREA				TEXT				NOT NULL,"
			 		+ "DESCRIPCION		TEXT				NOT NULL,"
			 		+ "MATERIALES		TEXT"
			 		+ ");";
			 stmt.executeUpdate(sql);
			 sql = "CREATE TABLE ACTIVIDADGRATUITA("
			 		+ "ID				INT PRIMARY KEY		NOT NULL,"
			 		+ "MONITORES		TEXT				NOT NULL,"
			 		+ "CUPO_MINIMO		INT					NOT NULL,"
			 		+ "CUPO_MAXIMO		INT					NOT NULL,"
			 		+ "CARACTERISTICAS	TEXT				NOT NULL,"
			 		+ "AREA				TEXT				NOT NULL,"
			 		+ "PUNTO_ENCUENTRO	TEXT				NOT NULL,"
			 		+ "MATERIALES		TEXT				NOT NULL,"
			 		+ "DIFICULTAD		TEXT"
			 		+ ")";
			 stmt.executeUpdate(sql);
			 stmt.close();
			 con.close();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
}
