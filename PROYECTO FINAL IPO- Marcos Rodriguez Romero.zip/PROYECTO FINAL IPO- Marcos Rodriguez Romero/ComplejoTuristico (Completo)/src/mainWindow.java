import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.JPanel;
import javax.swing.JPasswordField;

import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import java.awt.Panel;
import javax.swing.SwingConstants;

import modelo.Usuario;
import repositorio.usuarioRepository;

import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;

public class mainWindow {

	private JFrame frame;
	private JPanel panel;
	private JTextField usuarioTextField;
	private JPasswordField claveTextField;
	private JLabel mensajeLabel;
	private final Action action = new LoginAction();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainWindow window = new mainWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public JFrame getFrame() {
		return frame;
	}

	/**
	 * Create the application.
	 */
	public mainWindow() {
		initialize();		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(Color.WHITE);
		frame.setSize( 1024, 600);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		frame.getContentPane().add(panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] {500, 500};
		gbl_panel.rowHeights = new int[] {550};
		gbl_panel.columnWeights = new double[]{0.0, 1.0};
		gbl_panel.rowWeights = new double[]{1.0};
		panel.setLayout(gbl_panel);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(mainWindow.class.getResource("/images/loginleft.png")));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		panel.add(lblNewLabel, gbc_lblNewLabel);
		
		Panel panel_1 = new Panel();
		panel.add(panel_1);
		panel_1.setLayout(new GridLayout(0, 1, 0, 10));
		
		JLabel lblNewLabel_1 = new JLabel("Complejo Turistico - Ingresar al sistema");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Usuario");
		panel_1.add(lblNewLabel_2);
		
		usuarioTextField = new JTextField();
		panel_1.add(usuarioTextField);
		usuarioTextField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Clave");
		panel_1.add(lblNewLabel_3);
		
		claveTextField = new JPasswordField();
		panel_1.add(claveTextField);
		claveTextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Ingresar");
		btnNewButton.setAction(action);
		panel_1.add(btnNewButton);
		
		mensajeLabel = new JLabel("");
		panel_1.add(mensajeLabel);
	}

	private class LoginAction extends AbstractAction {
		/**
		 * 
		 */
		private static final long serialVersionUID = -8529617623251480844L;
		public LoginAction() {
			putValue(NAME, "Login");
			putValue(SHORT_DESCRIPTION, "Iniciar Sesi�n");
		}
		public void actionPerformed(ActionEvent e) {
			usuarioRepository ur = new usuarioRepository();
			Usuario usuarioLogin = ur.loginUsuario(usuarioTextField.getText(), claveTextField.getText());
			
			if(usuarioLogin == null) {
				mensajeLabel.setText("Credenciales incorrectas");
			}else {
				menuApplicationWindow menu =  new menuApplicationWindow();
				frame.getContentPane().removeAll();
				frame.setContentPane(menu.getPanel());
				
				frame.getContentPane().revalidate();	
				frame.getContentPane().repaint();

			}
			
		}
	}
	
}
