package modelo;

public class Alojamiento {
	private String disponibilidad;

	public Alojamiento(String disponibilidad) {
		super();
		this.disponibilidad = disponibilidad;
	}

	public String getDisponibilidad() {
		return disponibilidad;
	}

	public void setDisponibilidad(String disponibilidad) {
		this.disponibilidad = disponibilidad;
	}
}
