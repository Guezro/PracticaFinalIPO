package modelo;

public class Parcela extends Alojamiento{
	
	private int tipoParcela;
	private double tamano_x;
	private double tamano_y;
	private String ubicacion;
	private String[] servicio;
	public static int CABANA = 1;
	
	public Parcela(String disponibilidad, int tipoParcela, double tamano_x, double tamano_y, String ubicacion,
			String[] servicio) {
		super(disponibilidad);
		this.tipoParcela = tipoParcela;
		this.tamano_x = tamano_x;
		this.tamano_y = tamano_y;
		this.ubicacion = ubicacion;
		this.servicio = servicio;
	}

	public int getTipoParcela() {
		return tipoParcela;
	}

	public void setTipoParcela(int tipoParcela) {
		this.tipoParcela = tipoParcela;
	}

	public double getTamano_x() {
		return tamano_x;
	}

	public void setTamano_x(double tamano_x) {
		this.tamano_x = tamano_x;
	}

	public double getTamano_y() {
		return tamano_y;
	}

	public void setTamano_y(double tamano_y) {
		this.tamano_y = tamano_y;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String[] getServicio() {
		return servicio;
	}

	public void setServicio(String[] servicio) {
		this.servicio = servicio;
	}
	

}
