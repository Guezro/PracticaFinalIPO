package modelo;

public class Foto {
	
	private String ruta_archivo;

	public Foto(String ruta_archivo) {
		super();
		this.ruta_archivo = ruta_archivo;
	}

	public String getRuta_archivo() {
		return ruta_archivo;
	}

	public void setRuta_archivo(String ruta_archivo) {
		this.ruta_archivo = ruta_archivo;
	}
	
}
