package modelo;

public class Bungalow extends Alojamiento{
	
	private double tamano_x;
	private double tamano_y;
	private String ubicacion;
	private int capacidad;
	private double precio;
	private int estancia_minima;
	private int estancia_maxima;
	private Servicio servicio[];
	private String descripcion;
	private Foto galeria[];
	
	public Bungalow(String disponibilidad, double tamano_x, double tamano_y, String ubicacion, int capacidad,
			double precio, int estancia_minima, int estancia_maxima, Servicio[] servicio, String descripcion,
			Foto[] galeria) {
		super(disponibilidad);
		this.tamano_x = tamano_x;
		this.tamano_y = tamano_y;
		this.ubicacion = ubicacion;
		this.capacidad = capacidad;
		this.precio = precio;
		this.estancia_minima = estancia_minima;
		this.estancia_maxima = estancia_maxima;
		this.servicio = servicio;
		this.descripcion = descripcion;
		this.galeria = galeria;
	}

	public double getTamano_x() {
		return tamano_x;
	}

	public void setTamano_x(double tamano_x) {
		this.tamano_x = tamano_x;
	}

	public double getTamano_y() {
		return tamano_y;
	}

	public void setTamano_y(double tamano_y) {
		this.tamano_y = tamano_y;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public int getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getEstancia_minima() {
		return estancia_minima;
	}

	public void setEstancia_minima(int estancia_minima) {
		this.estancia_minima = estancia_minima;
	}

	public int getEstancia_maxima() {
		return estancia_maxima;
	}

	public void setEstancia_maxima(int estancia_maxima) {
		this.estancia_maxima = estancia_maxima;
	}

	public Servicio[] getServicio() {
		return servicio;
	}

	public void setServicio(Servicio[] servicio) {
		this.servicio = servicio;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Foto[] getGaleria() {
		return galeria;
	}

	public void setGaleria(Foto[] galeria) {
		this.galeria = galeria;
	}
	
	
	
}