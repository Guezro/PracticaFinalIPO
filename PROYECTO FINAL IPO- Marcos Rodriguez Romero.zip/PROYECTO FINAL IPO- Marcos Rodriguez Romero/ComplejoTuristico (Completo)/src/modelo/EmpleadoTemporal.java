package modelo;

import java.util.Date;

public class EmpleadoTemporal {
	
	private String nombre;
	private String telefono;
	private String email;
	private String idiomas;
	private String formacion;
	private String clave;
	private String avarat_url;
	private Date ultimo_acceso;
	private String restricciones;
	private String tipo;
	
	public EmpleadoTemporal(String nombre, String telefono, String email, String idiomas, String formacion,
			String clave, String avarat_url, Date ultimo_acceso, String restricciones, String tipo) {
		super();
		this.nombre = nombre;
		this.telefono = telefono;
		this.email = email;
		this.idiomas = idiomas;
		this.formacion = formacion;
		this.clave = clave;
		this.avarat_url = avarat_url;
		this.ultimo_acceso = ultimo_acceso;
		this.restricciones = restricciones;
		this.tipo = tipo;
	}

	public String getAvarat_url() {
		return avarat_url;
	}

	public void setAvarat_url(String avarat_url) {
		this.avarat_url = avarat_url;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIdiomas() {
		return idiomas;
	}

	public void setIdiomas(String idiomas) {
		this.idiomas = idiomas;
	}

	public String getFormacion() {
		return formacion;
	}

	public void setFormacion(String formacion) {
		this.formacion = formacion;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public Date getUltimo_acceso() {
		return ultimo_acceso;
	}

	public void setUltimo_acceso(Date ultimo_acceso) {
		this.ultimo_acceso = ultimo_acceso;
	}

	public String getRestricciones() {
		return restricciones;
	}

	public void setRestricciones(String restricciones) {
		this.restricciones = restricciones;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
}
