package modelo;

public class Actividad {
	private EmpleadoTemporal monitores[];
	private String horario;
	private int cupo_minimo;
	private int cupo_maximo;
	private String caracteristicas_destinatarios;
	private boolean precio_horames;
	private double precio;
	private String area;
	private String descripcion;
	private String materiales;
	
	public Actividad(EmpleadoTemporal[] monitores, String horario, int cupo_minimo, int cupo_maximo,
			String caracteristicas_destinatarios, boolean precio_horames, double precio, String area,
			String descripcion, String materiales) {
		super();
		this.monitores = monitores;
		this.horario = horario;
		this.cupo_minimo = cupo_minimo;
		this.cupo_maximo = cupo_maximo;
		this.caracteristicas_destinatarios = caracteristicas_destinatarios;
		this.precio_horames = precio_horames;
		this.precio = precio;
		this.area = area;
		this.descripcion = descripcion;
		this.materiales = materiales;
	}

	public EmpleadoTemporal[] getMonitores() {
		return monitores;
	}

	public void setMonitores(EmpleadoTemporal[] monitores) {
		this.monitores = monitores;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public int getCupo_minimo() {
		return cupo_minimo;
	}

	public void setCupo_minimo(int cupo_minimo) {
		this.cupo_minimo = cupo_minimo;
	}

	public int getCupo_maximo() {
		return cupo_maximo;
	}

	public void setCupo_maximo(int cupo_maximo) {
		this.cupo_maximo = cupo_maximo;
	}

	public String getCaracteristicas_destinatarios() {
		return caracteristicas_destinatarios;
	}

	public void setCaracteristicas_destinatarios(String caracteristicas_destinatarios) {
		this.caracteristicas_destinatarios = caracteristicas_destinatarios;
	}

	public boolean isPrecio_horames() {
		return precio_horames;
	}

	public void setPrecio_horames(boolean precio_horames) {
		this.precio_horames = precio_horames;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMateriales() {
		return materiales;
	}

	public void setMateriales(String materiales) {
		this.materiales = materiales;
	}
	
}
