package modelo;

import java.sql.Timestamp;

public class Reserva {
	
	private Timestamp fecha_entrada;
	private Timestamp fecha_salida;
	private Usuario realizado_por;
	private String telefono;
	private String email;
	private int ocupantes;
	private String solicitudes_especiales;
	
	public Reserva(Timestamp fecha_entrada, Timestamp fecha_salida, Usuario realizado_por, String telefono,
			String email, int ocupantes, String solicitudes_especiales) {
		super();
		this.fecha_entrada = fecha_entrada;
		this.fecha_salida = fecha_salida;
		this.realizado_por = realizado_por;
		this.telefono = telefono;
		this.email = email;
		this.ocupantes = ocupantes;
		this.solicitudes_especiales = solicitudes_especiales;
	}

	public Timestamp getFecha_entrada() {
		return fecha_entrada;
	}

	public void setFecha_entrada(Timestamp fecha_entrada) {
		this.fecha_entrada = fecha_entrada;
	}

	public Timestamp getFecha_salida() {
		return fecha_salida;
	}

	public void setFecha_salida(Timestamp fecha_salida) {
		this.fecha_salida = fecha_salida;
	}

	public Usuario getRealizado_por() {
		return realizado_por;
	}

	public void setRealizado_por(Usuario realizado_por) {
		this.realizado_por = realizado_por;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getOcupantes() {
		return ocupantes;
	}

	public void setOcupantes(int ocupantes) {
		this.ocupantes = ocupantes;
	}

	public String getSolicitudes_especiales() {
		return solicitudes_especiales;
	}

	public void setSolicitudes_especiales(String solicitudes_especiales) {
		this.solicitudes_especiales = solicitudes_especiales;
	}
	
}
