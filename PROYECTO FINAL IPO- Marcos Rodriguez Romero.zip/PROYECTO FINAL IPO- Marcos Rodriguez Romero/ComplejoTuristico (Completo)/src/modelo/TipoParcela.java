package modelo;

public class TipoParcela {
	
	private String nombre;
	private double precio_diurno;
	private double precio_nocturno;
	
	public TipoParcela(String nombre, double precio_diurno, double precio_nocturno) {
		super();
		this.nombre = nombre;
		this.precio_diurno = precio_diurno;
		this.precio_nocturno = precio_nocturno;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecio_diurno() {
		return precio_diurno;
	}

	public void setPrecio_diurno(double precio_diurno) {
		this.precio_diurno = precio_diurno;
	}

	public double getPrecio_nocturno() {
		return precio_nocturno;
	}

	public void setPrecio_nocturno(double precio_nocturno) {
		this.precio_nocturno = precio_nocturno;
	}
	
}
