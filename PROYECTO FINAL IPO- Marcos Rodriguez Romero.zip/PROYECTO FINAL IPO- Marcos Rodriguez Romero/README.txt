Soy alumno del máster en ingeniería informática, estoy cursando esta asignatura como complemento formativo.
Pensaba que la entrega era el día del examen de recuperación. Mandaré sin falta la memoria mañana día 26/05/2021 junto con el vídeo explicando su funcionamiento.

Gracias.
Un saludo,
Marcos.